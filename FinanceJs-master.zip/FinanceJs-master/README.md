Finance.js
==========
Finance.js provides basic finance javascript methods and was contributed by the excellent [Car Bounce](http://carbounce.com).

- Author: [Trent Richardson](http://trentrichardson.com)
- Twitter: [@practicalweb](http://twitter.com/practicalweb)

Version 0.1

Copyright 2012 Trent Richardson

You may use this project under MIT or GPL licenses.

http://trentrichardson.com/Impromptu/GPL-LICENSE.txt

http://trentrichardson.com/Impromptu/MIT-LICENSE.txt


