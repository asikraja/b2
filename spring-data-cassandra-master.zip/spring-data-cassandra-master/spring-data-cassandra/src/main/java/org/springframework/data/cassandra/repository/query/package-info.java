/**
 * Query derivation mechanism for Apache Cassandra specific repositories.
 */
@NonNullApi
package org.springframework.data.cassandra.repository.query;

import org.springframework.lang.NonNullApi;
