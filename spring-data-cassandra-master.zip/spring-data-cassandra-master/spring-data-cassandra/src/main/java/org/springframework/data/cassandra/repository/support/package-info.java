/**
 * Support infrastructure for query derivation of Apache Cassandra specific repositories.
 */
@NonNullApi
package org.springframework.data.cassandra.repository.support;

import org.springframework.lang.NonNullApi;
