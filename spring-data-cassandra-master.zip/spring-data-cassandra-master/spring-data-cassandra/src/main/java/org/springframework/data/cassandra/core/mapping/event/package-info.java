/**
 * Event callback infrastructure for Cassandra mapping subsystem.
 */
@NonNullApi
package org.springframework.data.cassandra.core.mapping.event;

import org.springframework.lang.NonNullApi;
