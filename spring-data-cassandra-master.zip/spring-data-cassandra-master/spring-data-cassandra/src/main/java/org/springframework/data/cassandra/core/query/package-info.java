/**
 * Apache Cassandra specific query and update support.
 */
@NonNullApi
package org.springframework.data.cassandra.core.query;

import org.springframework.lang.NonNullApi;
