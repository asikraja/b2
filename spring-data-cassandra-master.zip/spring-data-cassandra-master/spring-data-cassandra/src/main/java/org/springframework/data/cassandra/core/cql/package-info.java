/**
 * CQL core support.
 */
@NonNullApi
package org.springframework.data.cassandra.core.cql;

import org.springframework.lang.NonNullApi;
