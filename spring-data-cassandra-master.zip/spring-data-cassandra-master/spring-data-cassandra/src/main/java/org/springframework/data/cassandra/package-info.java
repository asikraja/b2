/**
 * Spring Data's Cassandra abstraction.
 */
@NonNullApi
package org.springframework.data.cassandra;

import org.springframework.lang.NonNullApi;
