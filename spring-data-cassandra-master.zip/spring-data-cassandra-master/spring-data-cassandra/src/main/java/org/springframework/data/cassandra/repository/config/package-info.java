/**
 * Support infrastructure for the configuration of Apache Cassandra specific repositories.
 */
@NonNullApi
package org.springframework.data.cassandra.repository.config;

import org.springframework.lang.NonNullApi;
