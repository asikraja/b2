/**
 * Apache Cassandra specific repository implementation.
 */
@NonNullApi
package org.springframework.data.cassandra.repository;

import org.springframework.lang.NonNullApi;
