/**
 * Spring Data Cassandra specific converter infrastructure.
 */
@NonNullApi
package org.springframework.data.cassandra.core.convert;

import org.springframework.lang.NonNullApi;
