/**
 * Infrastructure for the Apache Cassandra row-to-object mapping subsystem.
 */
@NonNullApi
package org.springframework.data.cassandra.core.mapping;

import org.springframework.lang.NonNullApi;
