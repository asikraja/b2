/**
 * CDI support for Apache Cassandra specific repository implementation.
 */
@NonNullApi
package org.springframework.data.cassandra.repository.cdi;

import org.springframework.lang.NonNullApi;
