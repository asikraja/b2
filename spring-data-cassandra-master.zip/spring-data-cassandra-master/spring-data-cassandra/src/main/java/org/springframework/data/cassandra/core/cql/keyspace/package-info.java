/**
 * Keyspace object action specifications such as {@code CREATE TABLE}, {@code DROP INDEX}.
 */
@NonNullApi
package org.springframework.data.cassandra.core.cql.keyspace;

import org.springframework.lang.NonNullApi;
