/**
 * Apache Cassandra core support.
 */
@NonNullApi
package org.springframework.data.cassandra.core;

import org.springframework.lang.NonNullApi;
