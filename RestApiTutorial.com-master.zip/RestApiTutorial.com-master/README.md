HTML source code for www.RestApiTutorial.com.

Also includes the PDF, ePub and Mobi (Kindle) versions of the associated RESTful Best Practices document.  In addition, the Libre/Open Office version of the source document is included in the 'media' directory.

![alt Creative Commons License](http://i.creativecommons.org/l/by-sa/4.0/88x31.png)

This work by <a xmlns:cc="http://creativecommons.org/ns#" href="http://www.restapitutorial.com/" property="cc:attributionName" rel="cc:attributionURL">RestApiTutorial.com</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.